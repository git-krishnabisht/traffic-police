package io.trafficpolice.capture.core;

import java.util.List;
import java.util.Map;

/**
 * A captured event, created on an app thread with raw data and encoded to a frame on the
 * writer thread, where it also gets its {@code seq} (PROTOCOL.md §7.1).
 */
abstract class Event {
    /** Which replay ring keeps the frame. */
    static final int RING_TXN = 0;
    static final int RING_DIAG = 1;
    static final int RING_TRAFFIC = 2;

    final long ts;
    /** Transaction id, or 0 for events that belong to no transaction. */
    final long txn;
    /** {@link #size()} when it was queued, so the queue takes away what it added (EventQueue). */
    int queued;

    Event(long ts, long txn) {
        this.ts = ts;
        this.txn = txn;
    }

    abstract byte[] encode(long seq);

    /**
     * Memory the event takes while queued, for the queue's budget: the object and its slot in the
     * queue, and everything it holds (strings, headers, stack frames, bytes). Estimated, without
     * the work of encoding it.
     */
    int size() {
        return 96;
    }

    /** Body bytes carried, for the ring's body budget. */
    int bodyBytes() {
        return 0;
    }

    int ring() {
        return txn != 0 ? RING_TXN : RING_DIAG;
    }

    Json start(String type, long seq) {
        Json j = new Json();
        j.obj().kv("t", type).kv("seq", seq).kv("ts", ts);
        if (txn != 0) {
            j.kv("txn", txn);
        }
        return j;
    }

    static int stringsSize(String[] a) {
        int n = 0;
        if (a != null) {
            for (String s : a) {
                n += stringSize(s);
            }
        }
        return n;
    }

    static int stringSize(String s) {
        return s == null ? 4 : s.length() * 2 + 24;
    }

    /**
     * A failure and its causes (the five that are sent at most), each with its message and its
     * trace, which is not resolved here (that is the costly part) and so counts a fixed share.
     */
    static int errorSize(Throwable error) {
        int n = 0;
        Throwable t = error;
        for (int i = 0; t != null && i < 5; i++) {
            n += 256;
            try {
                n += stringSize(t.getMessage());
                t = t.getCause();
            } catch (Throwable ignored) {
                // the app's own exception class; the message is read again when it is encoded
                t = null;
            }
        }
        return n;
    }

    static String dirName(int dir) {
        switch (dir) {
            case Frames.DIR_REQUEST:
                return "request";
            case Frames.DIR_RESPONSE:
                return "response";
            default:
                return "delivered";
        }
    }

    // --- transaction events ---------------------------------------------------------------

    /** {@code req}: request started. */
    static final class Req extends Event {
        final long call;
        final int hop;
        final String method;
        final String url;
        final String[] headers;
        final String clientKind;
        final String clientVersion;
        final ThreadStack stack;
        final BodyInfo body;
        final String[] markNames;
        final long[] markTimes;
        final ConnInfo conn;

        Req(long ts, long txn, long call, int hop, String method, String url, String[] headers, String clientKind,
                String clientVersion, ThreadStack stack, BodyInfo body, String[] markNames, long[] markTimes,
                ConnInfo conn) {
            super(ts, txn);
            this.call = call;
            this.hop = hop;
            this.method = method;
            this.url = url;
            this.headers = headers;
            this.clientKind = clientKind;
            this.clientVersion = clientVersion;
            this.stack = stack;
            this.body = body;
            this.markNames = markNames;
            this.markTimes = markTimes;
            this.conn = conn;
        }

        @Override
        int size() {
            return 256 + stringSize(url) + stringsSize(headers) + (stack == null ? 0 : stack.sizeEstimate() * 96)
                    + (markNames == null ? 0 : markNames.length * 24);
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("req", seq);
            j.kv("call", call).kv("hop", hop).kv("method", method).kv("url", url);
            j.headers("headers", headers);
            j.key("client").obj().kv("kind", clientKind);
            if (clientVersion != null) {
                j.kv("version", clientVersion);
            }
            j.endObj();
            if (stack != null) {
                stack.writeThread(j);
                stack.writeStack(j);
            }
            if (body != null) {
                j.key("body").obj().kv("length", body.length).kv("type", body.contentType)
                        .kv("one_shot", body.oneShot).kv("duplex", body.duplex).endObj();
            }
            j.key("marks").arr();
            if (markNames != null) {
                for (int i = 0; i < markNames.length; i++) {
                    j.arr().str(markNames[i]).num(markTimes[i]).endArr();
                }
            }
            j.endArr();
            if (conn != null) {
                j.key("conn");
                conn.write(j);
            }
            return Frames.json(j.endObj());
        }
    }

    /** What is known about a request body before it is written. */
    static final class BodyInfo {
        final long length;
        final String contentType;
        final boolean oneShot;
        final boolean duplex;

        BodyInfo(long length, String contentType, boolean oneShot, boolean duplex) {
            this.length = length;
            this.contentType = contentType;
            this.oneShot = oneShot;
            this.duplex = duplex;
        }
    }

    /** {@code resp}: response headers received. */
    static final class Resp extends Event {
        final int status;
        final String message;
        final String protocol;
        final String[] headers;
        final ConnInfo conn;

        Resp(long ts, long txn, int status, String message, String protocol, String[] headers, ConnInfo conn) {
            super(ts, txn);
            this.status = status;
            this.message = message;
            this.protocol = protocol;
            this.headers = headers;
            this.conn = conn;
        }

        @Override
        int size() {
            return 160 + stringsSize(headers);
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("resp", seq);
            j.kv("status", status).kv("message", message == null ? "" : message);
            if (protocol != null) {
                j.kv("protocol", protocol);
            }
            j.headers("headers", headers);
            if (conn != null) {
                j.key("conn");
                conn.write(j);
            }
            return Frames.json(j.endObj());
        }
    }

    /** A body chunk (frame type 2). */
    static final class Chunk extends Event {
        final int dir;
        final long offset;
        final byte[] data;

        Chunk(long ts, long txn, int dir, long offset, byte[] data) {
            super(ts, txn);
            this.dir = dir;
            this.offset = offset;
            this.data = data;
        }

        @Override
        int size() {
            return 64 + data.length;
        }

        @Override
        int bodyBytes() {
            return data.length;
        }

        @Override
        byte[] encode(long seq) {
            return Frames.body(seq, txn, dir, ts, offset, data, 0, data.length);
        }
    }

    /** {@code body_end}. */
    static final class BodyEnd extends Event {
        final int dir;
        final long bytes;
        final long captured;
        final String state;

        BodyEnd(long ts, long txn, int dir, long bytes, long captured, String state) {
            super(ts, txn);
            this.dir = dir;
            this.bytes = bytes;
            this.captured = captured;
            this.state = state;
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("body_end", seq);
            j.kv("dir", dirName(dir)).kv("bytes", bytes).kv("captured", captured).kv("state", state);
            return Frames.json(j.endObj());
        }
    }

    /** {@code prog}: progress past the capture cap. */
    static final class Prog extends Event {
        final int dir;
        final long bytes;

        Prog(long ts, long txn, int dir, long bytes) {
            super(ts, txn);
            this.dir = dir;
            this.bytes = bytes;
        }

        @Override
        byte[] encode(long seq) {
            return Frames.json(start("prog", seq).kv("dir", dirName(dir)).kv("bytes", bytes).endObj());
        }
    }

    /** {@code mark}. */
    static final class Mark extends Event {
        final String name;

        Mark(long ts, long txn, String name) {
            super(ts, txn);
            this.name = name;
        }

        @Override
        byte[] encode(long seq) {
            return Frames.json(start("mark", seq).kv("m", name).endObj());
        }
    }

    /** {@code rule}: rules changed this transaction. */
    static final class Rule extends Event {
        final List<RuleSet.Rule> rules;
        final List<RuleRun.Change> changes;
        final RuleRun.Delivered delivered;

        Rule(long ts, long txn, List<RuleSet.Rule> rules, List<RuleRun.Change> changes, RuleRun.Delivered delivered) {
            super(ts, txn);
            this.rules = rules;
            this.changes = changes;
            this.delivered = delivered;
        }

        @Override
        int size() {
            return 256 + changes.size() * 96 + (delivered == null ? 0 : stringsSize(delivered.headers));
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("rule", seq);
            j.key("rules").arr();
            for (RuleSet.Rule r : rules) {
                j.obj().kv("id", r.id);
                if (r.name != null) {
                    j.kv("name", r.name);
                }
                j.endObj();
            }
            j.endArr().key("changes").arr();
            for (RuleRun.Change c : changes) {
                c.write(j);
            }
            j.endArr();
            if (delivered != null) {
                j.key("delivered").obj().kv("status", delivered.code)
                        .kv("message", delivered.message == null ? "" : delivered.message);
                j.headers("headers", delivered.headers);
                j.endObj();
            }
            return Frames.json(j.endObj());
        }
    }

    /** {@code done}. */
    static final class Done extends Event {
        final String[] trailers;
        final Txn.GrpcStatus grpc;

        Done(long ts, long txn, String[] trailers, Txn.GrpcStatus grpc) {
            super(ts, txn);
            this.trailers = trailers;
            this.grpc = grpc;
        }

        @Override
        int size() {
            return 96 + stringsSize(trailers) + (grpc == null ? 0 : 64 + stringSize(grpc.message));
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("done", seq);
            writeTrailers(j, trailers, grpc);
            return Frames.json(j.endObj());
        }
    }

    /** {@code trailers} and {@code grpc} of {@code done} and {@code fail}, when there are any. */
    static void writeTrailers(Json j, String[] trailers, Txn.GrpcStatus grpc) {
        if (trailers != null && trailers.length > 0) {
            j.headers("trailers", trailers);
        }
        if (grpc != null) {
            j.key("grpc").obj().kv("code", grpc.code).kv("status", grpc.name);
            if (grpc.message != null) {
                j.kv("message", grpc.message);
            }
            j.endObj();
        }
    }

    /** {@code fail}. */
    static final class Fail extends Event {
        final String phase;
        final boolean canceled;
        final boolean simulated;
        final Throwable error;
        final ConnInfo conn;
        final String[] trailers;
        final Txn.GrpcStatus grpc;

        Fail(long ts, long txn, String phase, boolean canceled, boolean simulated, Throwable error, ConnInfo conn,
                String[] trailers, Txn.GrpcStatus grpc) {
            super(ts, txn);
            this.phase = phase;
            this.canceled = canceled;
            this.simulated = simulated;
            this.error = error;
            this.conn = conn;
            this.trailers = trailers;
            this.grpc = grpc;
        }

        @Override
        int size() {
            return 128 + errorSize(error) + stringsSize(trailers) + (grpc == null ? 0 : 64 + stringSize(grpc.message));
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("fail", seq);
            j.kv("phase", phase).kv("canceled", canceled).kv("simulated", simulated);
            j.key("error").obj().kv("class", error.getClass().getName()).kv("message", error.getMessage());
            j.key("causes").arr();
            Throwable c = error.getCause();
            for (int i = 0; c != null && c != error && i < 4; i++, c = c.getCause()) {
                j.obj().kv("class", c.getClass().getName()).kv("message", c.getMessage()).endObj();
            }
            j.endArr().endObj();
            if (conn != null) {
                j.key("conn");
                conn.write(j);
            }
            writeTrailers(j, trailers, grpc);
            return Frames.json(j.endObj());
        }
    }

    /**
     * {@code ws}: one WebSocket message, sent ({@code out}) or received, with its payload up to the
     * capture cap (text as text, binary as base64; PROTOCOL.md §7.1).
     */
    static final class Ws extends Event {
        final boolean out;
        final String op;
        final long size;
        final byte[] payload;
        final boolean text;
        final boolean truncated;
        final int code;
        final String reason;

        Ws(long ts, long txn, boolean out, String op, long size, byte[] payload, boolean text, boolean truncated,
                int code, String reason) {
            super(ts, txn);
            this.out = out;
            this.op = op;
            this.size = size;
            this.payload = payload;
            this.text = text;
            this.truncated = truncated;
            this.code = code;
            this.reason = reason;
        }

        @Override
        int size() {
            return 96 + (payload == null ? 0 : payload.length * (text ? 1 : 2));
        }

        @Override
        int bodyBytes() {
            return payload == null ? 0 : payload.length;
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("ws", seq);
            j.kv("dir", out ? "out" : "in").kv("op", op).kv("size", size);
            if (payload != null) {
                if (text) {
                    j.kv("text", new String(payload, Json.UTF_8));
                } else {
                    j.kv("base64", base64(payload));
                }
                if (truncated) {
                    j.kv("truncated", true);
                }
            }
            if (code >= 0) {
                j.kv("code", code);
            }
            if (reason != null) {
                j.kv("reason", reason);
            }
            return Frames.json(j.endObj());
        }

        private static final char[] ALPHABET =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

        /** Standard base64 with padding (java.util.Base64 needs API 26; the library runs from 21). */
        static String base64(byte[] b) {
            StringBuilder out = new StringBuilder((b.length + 2) / 3 * 4);
            for (int i = 0; i < b.length; i += 3) {
                int n = (b[i] & 0xff) << 16;
                if (i + 1 < b.length) n |= (b[i + 1] & 0xff) << 8;
                if (i + 2 < b.length) n |= b[i + 2] & 0xff;
                out.append(ALPHABET[(n >> 18) & 63]).append(ALPHABET[(n >> 12) & 63]);
                out.append(i + 1 < b.length ? ALPHABET[(n >> 6) & 63] : '=');
                out.append(i + 2 < b.length ? ALPHABET[n & 63] : '=');
            }
            return out.toString();
        }
    }

    // --- events outside transactions ---------------------------------------------------------

    /** {@code traffic}: whole-app byte counters. */
    static final class Traffic extends Event {
        final long rx;
        final long tx;
        final long since;

        Traffic(long ts, long rx, long tx, long since) {
            super(ts, 0);
            this.rx = rx;
            this.tx = tx;
            this.since = since;
        }

        @Override
        int ring() {
            return RING_TRAFFIC;
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("traffic", seq).kv("rx", rx).kv("tx", tx);
            if (since > 0) {
                j.kv("since", since);
            }
            return Frames.json(j.endObj());
        }
    }

    /** {@code diag}. */
    static final class Diag extends Event {
        final String level;
        final String code;
        final String message;
        final Map<String, String> data;

        Diag(long ts, String level, String code, String message, Map<String, String> data) {
            super(ts, 0);
            this.level = level;
            this.code = code;
            this.message = message;
            this.data = data;
        }

        @Override
        int size() {
            int n = 96 + stringSize(message);
            if (data != null) {
                for (Map.Entry<String, String> e : data.entrySet()) {
                    n += 48 + stringSize(e.getKey()) + stringSize(e.getValue());
                }
            }
            return n;
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("diag", seq).kv("level", level).kv("code", code).kv("message", message);
            if (data != null && !data.isEmpty()) {
                j.key("data").obj();
                for (Map.Entry<String, String> e : data.entrySet()) {
                    j.kv(e.getKey(), e.getValue());
                }
                j.endObj();
            }
            return Frames.json(j.endObj());
        }
    }

    /** {@code dropped}: events lost to queue overflow (created by the writer). */
    static final class Dropped extends Event {
        final long events;
        final long bytes;
        final long[] txns;
        final boolean txnsTruncated;

        Dropped(long ts, long events, long bytes, long[] txns, boolean txnsTruncated) {
            super(ts, 0);
            this.events = events;
            this.bytes = bytes;
            this.txns = txns;
            this.txnsTruncated = txnsTruncated;
        }

        @Override
        int size() {
            return 96 + txns.length * 8;
        }

        @Override
        byte[] encode(long seq) {
            Json j = start("dropped", seq).kv("events", events).kv("bytes", bytes);
            j.key("txns").arr();
            for (long t : txns) {
                j.num(t);
            }
            j.endArr().kv("txns_truncated", txnsTruncated);
            return Frames.json(j.endObj());
        }
    }
}
